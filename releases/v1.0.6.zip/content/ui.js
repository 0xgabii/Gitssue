const ui = {
  changeStyle(style) {
    Object.assign(document.getElementById('vGitssue').style, style);
  },
};